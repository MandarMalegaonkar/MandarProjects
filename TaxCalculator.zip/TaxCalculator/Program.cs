﻿using System;

namespace TaxCalculator
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to Tax Calculator !");

            Employee objEmployee = new Employee();
            objEmployee.GetInputsForTaxCalculation();
            objEmployee.PrintTaxDetails();
        }
    }

    public class Employee
    {
        private static string _strEmployeeName;
        private static decimal _dBasicSalary;
        private static decimal _dCalculatedSalary;
        private static decimal _dCalculatedMonthlyHRA;
        private static decimal _dYearlySalary;
        private static int _intNumberWorkingDays;
        private static decimal _dHRAPercentage;
        private static decimal _dConveyanceAllowanceAmount;
        private static decimal _dMedicalAllowanceAmount;
        private static decimal _dTaxableIncome;
        private static decimal _dTaxAmount = 0;

        public void GetInputsForTaxCalculation()
        {
            Console.WriteLine("Please enter below details :");
            Console.Write("Employee Name : ");
            _strEmployeeName = Console.ReadLine();
            Console.Write("Basic Salary : ");
            _dBasicSalary = Convert.ToDecimal(Console.ReadLine());
            Console.Write("Number of days worked in a month : ");
            _intNumberWorkingDays = Convert.ToInt32(Console.ReadLine());
            Console.Write("HRA Percentage : ");
            _dHRAPercentage = Convert.ToDecimal(Console.ReadLine());
            Console.Write("Conveyance Allowance Amount : ");
            _dConveyanceAllowanceAmount = Convert.ToDecimal(Console.ReadLine());
            Console.Write("Medical Allowance Amount : ");
            _dMedicalAllowanceAmount = Convert.ToDecimal(Console.ReadLine());

        }

        public void PrintTaxDetails()
        {
            Console.WriteLine("---------------------------------------------------");
            Console.WriteLine();
            Console.WriteLine("Employee Name : " + _strEmployeeName);
            _dCalculatedSalary = (_dBasicSalary / 30) * _intNumberWorkingDays;

            _dCalculatedMonthlyHRA = _dCalculatedSalary * (_dHRAPercentage / 100);

            _dCalculatedSalary = _dCalculatedSalary + _dCalculatedMonthlyHRA;
            Console.WriteLine("Salary : " + decimal.Round(_dCalculatedSalary,2));
            
            _dYearlySalary = _dCalculatedSalary * 12;
            _dTaxableIncome = _dYearlySalary - ((_dConveyanceAllowanceAmount + _dMedicalAllowanceAmount + _dCalculatedMonthlyHRA) * 12);

            _dTaxableIncome = _dTaxableIncome - 250000; // To deduct default amount from calculation

            Console.WriteLine("Taxable Income : " + decimal.Round(_dTaxableIncome, 2));

            if (_dTaxableIncome > 250000 && _dTaxableIncome <= 500000)
            {
                _dTaxAmount = (_dTaxableIncome * 5)/ 100; // 5%
            }
            else if (_dTaxableIncome > 500000 && _dTaxableIncome <= 1000000)
            {
                _dTaxAmount = (_dTaxableIncome * 20) / 100; // 20%
            }
            else if (_dTaxableIncome > 1000000)
            {
                _dTaxAmount = (_dTaxableIncome * 30) / 100;// 30%
            }

            Console.WriteLine("Tax Amount : " + decimal.Round(_dTaxAmount,2));
        }
    }
}
